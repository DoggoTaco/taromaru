#### A package for the Taromaru API.


##### Image Example:

```py
    from taromaru import taromaruInit

    taromaru = taromaruInit("YOUR API KEY HERE")

    results = taromaru.image(type="kanna")

    print(results)
```

[Temp API Location](https://doggo-clicker.000webhostapp.com)